const express = require('express');
const { recordAttendance, getAttendanceByEnrollment } = require('../models/attendanceModel');
const router = express.Router();

router.post('/', async (req, res) => {
  const { enrollmentId, attendanceDate, status } = req.body;
  try {
    const id = await recordAttendance(enrollmentId, attendanceDate, status);
    res.json({ id, message: 'Attendance recorded' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/:enrollmentId', async (req, res) => {
  const records = await getAttendanceByEnrollment(req.params.enrollmentId);
  res.json(records);
});

module.exports = router;
