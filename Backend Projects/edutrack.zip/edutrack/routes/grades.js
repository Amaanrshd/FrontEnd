const express = require('express');
const { addGrade, getGradesByEnrollment, calculateAverage } = require('../models/gradeModel');

const router = express.Router();

// Add grade
router.post('/', async (req, res) => {
  const { enrollmentId, assignmentName, score, maxScore } = req.body;
  try {
    const gradeId = await addGrade(enrollmentId, assignmentName, score, maxScore);
    res.json({ id: gradeId, message: 'Grade added' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all grades by enrollment
router.get('/:enrollmentId', async (req, res) => {
  const grades = await getGradesByEnrollment(req.params.enrollmentId);
  res.json(grades);
});

// Get average score for enrollment
router.get('/:enrollmentId/average', async (req, res) => {
  const average = await calculateAverage(req.params.enrollmentId);
  res.json({ average_percentage: average });
});

module.exports = router;
