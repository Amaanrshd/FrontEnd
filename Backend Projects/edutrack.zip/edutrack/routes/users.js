const express = require('express');
const bcrypt = require('bcryptjs');
const { createUser, getUserByEmail, getUserById, updateUserProfile } = require('../models/userModel');
const router = express.Router();

// Registration
router.post('/register', async (req, res) => {
  const { name, email, password, role, departmentId } = req.body;
  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: 'Missing fields' });
  }
  try {
    const hash = await bcrypt.hash(password, 10);
    const userId = await createUser(name, email, hash, role, departmentId || null);
    res.json({ id: userId, message: 'User registered' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Missing fields' });
  }
  try {
    const user = await getUserByEmail(email);
    if (!user) return res.status(401).json({ error: 'Invalid email or password' });
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'Invalid email or password' });
    res.json({ id: user.id, role: user.role, message: 'Login successful' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get profile by ID
router.get('/:id', async (req, res) => {
  const userId = req.params.id;
  try {
    const user = await getUserById(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });
    delete user.password;
    res.json(user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update profile
router.put('/:id', async (req, res) => {
  const userId = req.params.id;
  const { name, email, role, departmentId } = req.body;
  try {
    await updateUserProfile(userId, name, email, role, departmentId || null);
    res.json({ message: 'Profile updated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
