const express = require('express');
const {
  createCourse,
  getAllCourses,
  getCourseById,
  updateCourse,
  deleteCourse
} = require('../models/courseModel');

const router = express.Router();

router.post('/', async (req, res) => {
  const { name, description, facultyId } = req.body;
  try {
    const courseId = await createCourse(name, description, facultyId);
    res.json({ id: courseId, message: 'Course created' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/', async (req, res) => {
  const courses = await getAllCourses();
  res.json(courses);
});

router.get('/:id', async (req, res) => {
  const course = await getCourseById(req.params.id);
  if (!course) return res.status(404).json({ error: 'Course not found' });
  res.json(course);
});

router.put('/:id', async (req, res) => {
  const { name, description, facultyId } = req.body;
  try {
    await updateCourse(req.params.id, name, description, facultyId);
    res.json({ message: 'Course updated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    await deleteCourse(req.params.id);
    res.json({ message: 'Course deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
