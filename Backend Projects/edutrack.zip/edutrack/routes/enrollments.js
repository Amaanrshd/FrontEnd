const express = require('express');
const {
  enrollStudent,
  getEnrollmentsByStudent,
  getEnrollmentsByCourse,
  removeEnrollment
} = require('../models/enrollmentModel');

const router = express.Router();

router.post('/', async (req, res) => {
  const { studentId, courseId } = req.body;
  try {
    const id = await enrollStudent(studentId, courseId);
    res.json({ id, message: 'Student enrolled' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error or duplicate enrollment' });
  }
});

router.get('/student/:studentId', async (req, res) => {
  const enrollments = await getEnrollmentsByStudent(req.params.studentId);
  res.json(enrollments);
});

router.get('/course/:courseId', async (req, res) => {
  const enrollments = await getEnrollmentsByCourse(req.params.courseId);
  res.json(enrollments);
});

router.delete('/:id', async (req, res) => {
  try {
    await removeEnrollment(req.params.id);
    res.json({ message: 'Enrollment removed' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
