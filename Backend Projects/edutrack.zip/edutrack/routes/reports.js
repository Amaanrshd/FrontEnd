const express = require('express');
const db = require('../db');
const router = express.Router();
const { Parser } = require('json2csv'); // npm install json2csv

// Export grades for a course in JSON or CSV
router.get('/grades/export', async (req, res) => {
  const { courseId, format } = req.query;
  try {
    const [results] = await db.query(`
      SELECT u.name as student_name, u.email, g.assignment_name, g.score, g.max_score
      FROM grades g
      JOIN enrollments e ON g.enrollment_id = e.id
      JOIN users u ON e.student_id = u.id
      WHERE e.course_id = ?
    `, [courseId]);

    if (format === 'csv') {
      const fields = ['student_name', 'email', 'assignment_name', 'score', 'max_score'];
      const parser = new Parser({ fields });
      const csv = parser.parse(results);
      res.header('Content-Type', 'text/csv');
      res.attachment('grades.csv');
      return res.send(csv);
    } else {
      // Default to JSON
      res.json(results);
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router
