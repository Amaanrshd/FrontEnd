const express = require('express');
const db = require('../db');
const router = express.Router();

// System overview: total users, courses, enrollments
router.get('/overview', async (req, res) => {
  try {
    const [[{ userCount }]] = await db.query('SELECT COUNT(*) as userCount FROM users');
    const [[{ facultyCount }]] = await db.query('SELECT COUNT(*) as facultyCount FROM users WHERE role = "faculty"');
    const [[{ studentCount }]] = await db.query('SELECT COUNT(*) as studentCount FROM users WHERE role = "student"');
    const [[{ courseCount }]] = await db.query('SELECT COUNT(*) as courseCount FROM courses');
    const [[{ enrollmentCount }]] = await db.query('SELECT COUNT(*) as enrollmentCount FROM enrollments');
    res.json({ userCount, facultyCount, studentCount, courseCount, enrollmentCount });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// List all departments
router.get('/departments', async (req, res) => {
  try {
    const [departments] = await db.query('SELECT * FROM departments');
    res.json(departments);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/departments', async (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'Department name required' });
  try {
    const [result] = await db.query('INSERT INTO departments (name) VALUES (?)', [name]);
    res.json({ id: result.insertId, name });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
