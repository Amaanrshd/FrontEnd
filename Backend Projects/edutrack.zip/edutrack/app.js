const express = require('express');
const app = express();

const userRoutes = require('./routes/users');

app.use(express.json()); 
app.use('/users', userRoutes);

app.get('/', (req, res) => {
  res.send('EduTrack API is running!');
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});

const courseRoutes = require('./routes/courses');
app.use('/courses', courseRoutes);

const enrollmentRoutes = require('./routes/enrollments');
app.use('/enrollments', enrollmentRoutes);

const gradeRoutes = require('./routes/grades');
app.use('/grades', gradeRoutes);

const attendanceRoutes = require('./routes/attendance');
app.use('/attendance', attendanceRoutes);

const reportRoutes = require('./routes/reports');
app.use('/reports', reportRoutes);

const adminRoutes = require('./routes/admin');
app.use('/admin', adminRoutes);
