const db = require('../db');

async function recordAttendance(enrollmentId, attendanceDate, status) {
  const [result] = await db.query(
    'INSERT INTO attendance (enrollment_id, attendance_date, status) VALUES (?, ?, ?)',
    [enrollmentId, attendanceDate, status]
  );
  return result.insertId;
}

async function getAttendanceByEnrollment(enrollmentId) {
  const [rows] = await db.query(
    'SELECT * FROM attendance WHERE enrollment_id = ? ORDER BY attendance_date',
    [enrollmentId]
  );
  return rows;
}

module.exports = { recordAttendance, getAttendanceByEnrollment };
