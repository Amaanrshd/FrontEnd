const db = require('../db');

async function addGrade(enrollmentId, assignmentName, score, maxScore) {
  const [result] = await db.query(
    'INSERT INTO grades (enrollment_id, assignment_name, score, max_score) VALUES (?, ?, ?, ?)',
    [enrollmentId, assignmentName, score, maxScore]
  );
  return result.insertId;
}

async function getGradesByEnrollment(enrollmentId) {
  const [rows] = await db.query(
    'SELECT * FROM grades WHERE enrollment_id = ?',
    [enrollmentId]
  );
  return rows;
}

async function calculateAverage(enrollmentId) {
  const [rows] = await db.query(
    `SELECT AVG(score/max_score*100) as average_percentage FROM grades WHERE enrollment_id = ?`,
    [enrollmentId]
  );
  return rows[0]?.average_percentage || 0;
}

module.exports = { addGrade, getGradesByEnrollment, calculateAverage };
