const db = require('../db');

async function createCourse(name, description, facultyId) {
  const [result] = await db.query(
    'INSERT INTO courses (name, description, faculty_id) VALUES (?, ?, ?)',
    [name, description, facultyId]
  );
  return result.insertId;
}

async function getAllCourses() {
  const [rows] = await db.query('SELECT * FROM courses');
  return rows;
}

async function getCourseById(id) {
  const [rows] = await db.query('SELECT * FROM courses WHERE id = ?', [id]);
  return rows[0];
}

async function updateCourse(id, name, description, facultyId) {
  await db.query(
    'UPDATE courses SET name = ?, description = ?, faculty_id = ? WHERE id = ?',
    [name, description, facultyId, id]
  );
}

async function deleteCourse(id) {
  await db.query('DELETE FROM courses WHERE id = ?', [id]);
}

module.exports = {
  createCourse,
  getAllCourses,
  getCourseById,
  updateCourse,
  deleteCourse
};
