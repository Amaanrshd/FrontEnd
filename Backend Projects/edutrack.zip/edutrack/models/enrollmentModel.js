const db = require('../db');

async function enrollStudent(studentId, courseId) {
  const [result] = await db.query(
    'INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)',
    [studentId, courseId]
  );
  return result.insertId;
}

async function getEnrollmentsByStudent(studentId) {
  const [rows] = await db.query(
    `SELECT e.id, c.name as course_name, c.description
     FROM enrollments e
     JOIN courses c ON e.course_id = c.id
     WHERE e.student_id = ?`,
    [studentId]
  );
  return rows;
}

async function getEnrollmentsByCourse(courseId) {
  const [rows] = await db.query(
    `SELECT e.id, u.name as student_name, u.email
     FROM enrollments e
     JOIN users u ON e.student_id = u.id
     WHERE e.course_id = ?`,
    [courseId]
  );
  return rows;
}

async function removeEnrollment(id) {
  await db.query('DELETE FROM enrollments WHERE id = ?', [id]);
}

module.exports = { enrollStudent, getEnrollmentsByStudent, getEnrollmentsByCourse, removeEnrollment };
