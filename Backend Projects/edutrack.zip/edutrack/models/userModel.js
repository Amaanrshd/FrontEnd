const db = require('../db');

async function createUser(name, email, passwordHash, role, departmentId) {
  const [result] = await db.query(
    'INSERT INTO users (name, email, password, role, department_id) VALUES (?, ?, ?, ?, ?)', 
    [name, email, passwordHash, role, departmentId || null]
  );
  return result.insertId;
}

async function getUserByEmail(email) {
  const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
  return rows[0];
}

async function getUserById(id) {
  const [rows] = await db.query('SELECT * FROM users WHERE id = ?', [id]);
  return rows[0];
}

async function updateUserProfile(id, name, email, role, departmentId) {
  await db.query(
    'UPDATE users SET name = ?, email = ?, role = ?, department_id = ? WHERE id = ?',
    [name, email, role, departmentId || null, id]
  );
}

module.exports = { createUser, getUserByEmail, getUserById, updateUserProfile };
